package product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    private Connection con;
    

    public ProductDAO() {
        String url = "jdbc:mysql://localhost:3306/portfolio?serverTimezone=Asia/Seoul";
        String user = "root";
        String password = "12345";

        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?serverTimezone=Asia/Seoul", "root", "12345");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public List<ProductVO> listProducts() {
        List<ProductVO> list = new ArrayList<>();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = con.prepareStatement("select * from user");
            rs = pstmt.executeQuery();

            while (rs.next()) {
                ProductVO product = new ProductVO();
                product.setProduct_id(rs.getString("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                list.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return list;
    }

    // addProduct, delProduct 메소드 등도 추가해주어야 합니다.
		public void addProduct(ProductVO productVO) {
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&amp;serverTimezone=Asia/Seoul", "root", "12345");
				PreparedStatement pstmt = null;
				String product_id = productVO.getProduct_id();
				String name = productVO.getName();
				String description = productVO.getDescription();
				
				
				String query = "insert into review(product_id, name, description)";
				query += " values (?, ?, ?)";
				System.out.println("prepareStatement: " + query);
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, product_id);
				pstmt.setString(2, name);
				pstmt.setString(3, description);
				pstmt.executeUpdate();
				pstmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void delProduct(String product_id) {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&amp;serverTimezone=Asia/Seoul", "root", "12345");
			PreparedStatement pstmt = null;
			String query = "delete from review where product_id=?";
			System.out.println("prepareStatement: " + query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, product_id);
			pstmt.executeUpdate();
			pstmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
}