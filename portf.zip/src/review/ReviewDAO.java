package review;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.jdbc.MysqlDataSourceFactory;

import product.ProductVO;
import user.MemberVO;

public class ReviewDAO {
		
		private Connection con;
		private PreparedStatement pstmt;
		
		public ReviewDAO() {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url = "jdbc:mysql://localhost:3306/portfolio";
				String user = "root";
				String password = "12345";
				con = DriverManager.getConnection(url, user, password);
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		
		public List<ReviewVO> listMembers(){
			List<ReviewVO> list = new ArrayList<>();
			
			try {
				String query = "select * from review";
				System.out.println("prepareStatement: " + query);
				pstmt = con.prepareStatement(query);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					String review_id = rs.getString("review_id");
					String content = rs.getString("content");
					String product_id = rs.getString("product_id");
					String user_id = rs.getString("user_id");

					// ProductVO 객체 생성
					ProductVO product = new ProductVO();
					product.setProduct_id(product_id);

					// MemberVO 객체 생성
					MemberVO user = new MemberVO();
					user.setUser_id(user_id);

					// ReviewVO 객체 생성
					ReviewVO review = new ReviewVO();
					review.setReview_id(review_id);
					review.setContent(content);
					review.setProduct(product);
					review.setUser(user);

					
				}
				rs.close();
				pstmt.close();
				con.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
			return list;
			
	}
		public void addReview(ReviewVO reviewVO) {
			try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&amp;serverTimezone=Asia/Seoul", "root", "12345");
			String review_id = reviewVO.getReview_id();
			String content = reviewVO.getContent();
			String product_id = reviewVO.getProduct().getProduct_id();
			String user_id = reviewVO.getUser().getUser_id();
			
			String query = "insert into review(review_id, content, product_id, user_id)";
			query += " values (?, ?, ?, ?)";
			System.out.println("prepareStatement: " + query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, review_id);
			pstmt.setString(2, content);
			pstmt.setString(3, product_id);
			pstmt.setString(4, user_id);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		}

		public void delReview(String review_id) {
		try {
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&amp;serverTimezone=Asia/Seoul", "root", "12345");

		String query = "delete from review where review_id=?";
		System.out.println("prepareStatement: " + query);
		pstmt = con.prepareStatement(query);
		pstmt.setString(1, review_id);
		pstmt.executeUpdate();
		pstmt.close();
	} catch (Exception e) {
		e.printStackTrace();
	}
		}
}