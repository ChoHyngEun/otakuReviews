package review;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import product.ProductVO;

/**
 * Servlet implementation class ReviewServlet
 */
@WebServlet("/review")
public class ReviewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doHandle(request, response);
	}
	
	protected void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setCharacterEncoding("utf-8");
	    response.setContentType("text/html;charset=utf-8"); //need this so Korean letters show correctly
	    ReviewDAO dao = new ReviewDAO();
	    PrintWriter out = response.getWriter();
	    String command = request.getParameter("command");

	    if (command != null && command.equals("addMember")) {
	        String review_id = request.getParameter("review_id");
	        String content = request.getParameter("content");
	        String product_id = request.getParameter("product_id");
	        String user_id = request.getParameter("user_id");

	        // ProductVO 객체 생성
	        ProductVO product = new ProductVO();
	        product.setProduct_id(product_id);

	        // MemberVO 객체 생성
	        user.MemberVO user = new user.MemberVO();
	        user.setUser_id(user_id);

	        // ReviewVO 객체 생성
	        ReviewVO review = new ReviewVO();
	        review.setReview_id(review_id);
	        review.setContent(content);
	        review.setProduct(product);
	        review.setUser(user);
	        
	        dao.addReview(review); // addMember 메소드를 호출하여 새로운 ReviewVO 객체 추가
	    } else if (command != null && command.equals("delMember")) {
	        String review_id = request.getParameter("review_id");
	        dao.delReview(review_id);
	    }

	    List<ReviewVO> list = dao.listMembers();
	    out.print("<html><body>");
	    out.print("<table border=1><tr align='center' bgcolor='lightgreen'>");
	    out.print("<td>아이디</td><td>내용</td><td>제품 ID</td><td>사용자 ID</td><td>삭제</td></tr>");

	    for (int i = 0; i < list.size(); i++) {
	        ReviewVO reviewVo = list.get(i);
	        String review_id = reviewVo.getReview_id();
	        String content = reviewVo.getContent();
	        String product_id = reviewVo.getProduct().getProduct_id();
	        String user_id = reviewVo.getUser().getUser_id();

	        out.print("<tr><td>" + review_id + "</td><td>" + content + "</td><td>" + product_id + "</td><td>" + user_id + "</td>");
	        out.print("<td><a href='/review.do?command=delMember&review_id=" + review_id + "'>삭제</a></td></tr>");
	    }

	    out.print("</table></body></html>");
	}
}


