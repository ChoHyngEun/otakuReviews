package review;

import product.ProductVO;
import user.MemberVO;

public class ReviewVO {

	
	private String review_id;
	private String content;
	private ProductVO product_id;
	private MemberVO user_id;
	
	
	public String getReview_id() {
		return review_id;
	}
	public void setReview_id(String review_id) {
		this.review_id = review_id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public ProductVO getProduct() {
		return product_id;
	}
	public void setProduct(ProductVO product_id) {
		this.product_id = product_id;
	}
	public MemberVO getUser() {
		return user_id;
	}
	public void setUser(MemberVO user_id) {
		this.user_id = user_id;
	}
	
	
	
	
}
