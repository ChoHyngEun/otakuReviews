package user;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {
		
		private Connection con;
		private PreparedStatement pstmt;
		
		public MemberDAO() {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url = "jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&amp;serverTimezone=Asia/Seoul";
				String user = "root";
				String password = "12345";
				con = DriverManager.getConnection(url, user, password);
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		
		public List<MemberVO> listMembers(){
			List<MemberVO> list = new ArrayList<>();
			
			try {
				String query = "select * from user";
				System.out.println("prepareStatement: " + query);
				pstmt = con.prepareStatement(query);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					String id = rs.getString("user_id");
					String pwd = rs.getString("password");
					String name = rs.getString("name");
					String email = rs.getString("email");
					MemberVO vo = new MemberVO();
					vo.setUser_id(id);
					vo.setPassword(pwd);
					vo.setName(name);
					vo.setEmail(email);
					list.add(vo);
					
				}
				rs.close();
				pstmt.close();
				con.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
			return list;
			
	}
}