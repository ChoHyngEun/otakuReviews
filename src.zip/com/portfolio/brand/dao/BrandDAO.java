package com.portfolio.brand.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.portfolio.brand.model.ProductBrand;

public class BrandDAO {
	
	private Connection con;
	
	public BrandDAO() {
        String url = "jdbc:mysql://localhost:3306/portfolio?serverTimezone=Asia/Seoul";
        String user = "root";
        String password = "root";

        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?serverTimezone=Asia/Seoul", "root", "root");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
	
	public List<ProductBrand> listProductBrands() {
		List<ProductBrand> list = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
            pstmt = con.prepareStatement("select * from brand");
            rs = pstmt.executeQuery();

            while (rs.next()) {
                ProductBrand productBrand = new ProductBrand();
                productBrand.setBrand_id(rs.getString("brand_id"));
                productBrand.setBrand_name(rs.getString("brand_name"));
                list.add(productBrand);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return list;
    }

	//add del
	public void delBrand(String brand_id) {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&amp;serverTimezone=Asia/Seoul#product", "root", "root");
			PreparedStatement pstmt = null;
			String query = "delete from brand where brand_id=?";
			System.out.println("prepareStatement: " + query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, brand_id);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
