package com.portfolio.product.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.portfolio.product.dao.ProductDAO;
import com.portfolio.product.model.ProductVO;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/product")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doHandle(request, response);
	}
	
	protected void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setCharacterEncoding("utf-8");
	    response.setContentType("text/html;charset=utf-8"); //need this so Korean letters show correctly
	    ProductDAO dao = new ProductDAO();
	    PrintWriter out = response.getWriter();
	    String command = request.getParameter("command");

	    if (command != null && command.equals("addProduct")) {
	        String product_id = request.getParameter("product_id");
	        String product_name = request.getParameter("product_name");
	        String prdoduct_info = request.getParameter("product_info");

	        // ProductVO 객체 생성
	        ProductVO product = new ProductVO();
	        product.setProduct_id(product_id);
	        product.setProduct_info(prdoduct_info);
	        product.setProduct_name(product_name);
	        

	        
	        dao.addProduct(product); // addproduct 메소드를 호출하여 새로운 ReviewVO 객체 추가
	    } else if (command != null && command.equals("delProduct")) {
	        String product_id = request.getParameter("product_id");
	        dao.delProduct(product_id);
	    }

	    List<ProductVO> list = dao.listProducts();
	    out.print("<html><body>");
	    out.print("<table border=1><tr align='center' bgcolor='lightgreen'>");
	    out.print("<td>제품 아이디</td><td>제품명</td><td>제품 설명 ID</td><td>삭제</td></tr>");

	    for (int i = 0; i < list.size(); i++) {
	        ProductVO productVo = list.get(i);
	        String product_id =	productVo.getProduct_id();
	        String product_name = productVo.getProduct_name();
	        String product_info = productVo.getProduct_info();

	        out.print("<tr><td>" + product_id + "</td><td>" + product_name + "</td><td>" + product_info + "</td>");
	        out.print("<td><a href='/review.do?command=delMember&review_id=" + product_id + "'>삭제</a></td></tr>");
	    }

	    out.print("</table></body></html>");
	}
}

