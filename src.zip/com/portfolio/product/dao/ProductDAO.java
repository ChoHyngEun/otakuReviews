package com.portfolio.product.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.portfolio.brand.model.ProductBrand;
import com.portfolio.product.model.ProductVO;

public class ProductDAO {
    private Connection con;
    

    public ProductDAO() {
        String url = "jdbc:mysql://localhost:3306/portfolio?serverTimezone=Asia/Seoul";
        String user = "root";
        String password = "root";

        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?serverTimezone=Asia/Seoul", "root", "root");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public List<ProductVO> listProducts() {
        List<ProductVO> list = new ArrayList<>();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = con.prepareStatement("select * from product");
            rs = pstmt.executeQuery();

            while (rs.next()) {

            	
                ProductVO product = new ProductVO();
                product.setProduct_id(rs.getString("product_id"));
                product.setProduct_name(rs.getString("product_name"));
                product.setProduct_info(rs.getString("product_info"));
                product.setProduct_img(rs.getString("product_img"));
                product.setCategory(rs.getString("category"));
               
                ProductBrand productbrand = new ProductBrand();
                productbrand.setBrand_id(rs.getString("brand_id"));
                productbrand.setBrand_name(rs.getString("brand_name"));
                
                list.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return list;
    }

    // addProduct, delProduct 메소드 등도 추가해주어야 합니다.
		public void addProduct(ProductVO productVO) {
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&amp;serverTimezone=Asia/Seoul", "root", "root");
				PreparedStatement pstmt = null;
				String product_id = productVO.getProduct_id();
				String product_name = productVO.getProduct_name();
				String product_info = productVO.getProduct_info();
				String product_img = productVO.getProduct_img();
				String brand_id = productVO.getBrand_id().getBrand_id();
				String brand_name = productVO.getBrand_name().getBrand_name();
				
				
				String query = "insert into review(product_id, name, description)";
				query += " values (?, ?, ?)";
				System.out.println("prepareStatement: " + query);
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, product_id);
				pstmt.setString(2, product_name);
				pstmt.setString(3, product_info);
				pstmt.setString(4, product_img);
				pstmt.setString(5, brand_id);
				pstmt.setString(6, brand_name);
				pstmt.executeUpdate();
				pstmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void delProduct(String product_id) {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&amp;serverTimezone=Asia/Seoul#product", "root", "root");
			PreparedStatement pstmt = null;
			String query = "delete from review where product_id=?";
			System.out.println("prepareStatement: " + query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, product_id);
			pstmt.executeUpdate();
			pstmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
}