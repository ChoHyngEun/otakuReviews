package com.portfolio.product.model;

import com.portfolio.brand.model.ProductBrand;

public class ProductVO {
	private String product_id;
	private String product_name;
	private String product_info;
	private String category;
	private String product_img;
	ProductBrand brand_id;
	ProductBrand brand_name;
	
	
	public  ProductVO() {
		
	}


	public String getProduct_id() {
		return product_id;
	}


	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}


	public String getProduct_name() {
		return product_name;
	}


	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}


	public String getProduct_info() {
		return product_info;
	}


	public void setProduct_info(String product_info) {
		this.product_info = product_info;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getProduct_img() {
		return product_img;
	}


	public void setProduct_img(String product_img) {
		this.product_img = product_img;
	}


	public ProductBrand getBrand_id() {
		return brand_id;
	}


	public void setBrand_id(ProductBrand brand_id) {
		this.brand_id = brand_id;
	}


	public ProductBrand getBrand_name() {
		return brand_name;
	}


	public void setBrand_name(ProductBrand brand_name) {
		this.brand_name = brand_name;
	}

	
}
