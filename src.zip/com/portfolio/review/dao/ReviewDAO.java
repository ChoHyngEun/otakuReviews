package com.portfolio.review.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.portfolio.product.model.ProductVO;
import com.portfolio.registration.model.User;
import com.portfolio.review.model.ReviewVO;

public class ReviewDAO {
    private Connection con;
    private PreparedStatement pstmt;

    public ReviewDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&serverTimezone=Asia/Seoul";
            String user = "root";
            String password = "root";
            con = DriverManager.getConnection(url, user, password);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public List<ReviewVO> listMembers() {
        List<ReviewVO> list = new ArrayList<>();
        try {
            String query = "select * from review";
            System.out.println("prepareStatement: " + query);
            pstmt = con.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String review_id = rs.getString("review_id");
                String content = rs.getString("content");
                String product_id = rs.getString("product_id");
                String product_name = rs.getString("product_name");
                String userName = rs.getString("userName");
                Date reviewdate = rs.getDate("reviewdate");
                String likes = rs.getString("likes");
                String veiw_count = rs.getString("veiw_count");
                String product_info = rs.getString("product_info");
                String product_img = rs.getString("product_img");

                // ProductVO 객체 생성
                ProductVO product = new ProductVO();
                product.setProduct_id(product_id);
                product.setProduct_name(product_name);
                product.setProduct_info(product_info);
                product.setProduct_img(product_img);
                

                // User 객체 생성
                User user = new User();
                user.setUserName(userName);

                // ReviewVO 객체 생성
                ReviewVO review = new ReviewVO();
                review.setReview_id(review_id);
                review.setContent(content);
                review.setProduct_id(product);
                review.setUserName(user);
                review.setProduct_info(product);
                review.setProduct_name(product);
                review.setReviewdate(reviewdate);;
                review.setLikes(likes);
                review.setView_count(veiw_count);
                review.setProduct_img(product);

                // 리스트에 추가
                list.add(review);
            }
            rs.close();
            pstmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void addReview(ReviewVO reviewVO) {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&serverTimezone=Asia/Seoul", "root", "root");
            String review_id = reviewVO.getReview_id();
            String content = reviewVO.getContent();
            String product_id = reviewVO.getProduct_id().getProduct_id();
            String userName = reviewVO.getUserName().getUserName();
            String product_name = reviewVO.getProduct_name().getProduct_name();
            String likes = reviewVO.getLikes();
            String veiw_count = reviewVO.getView_count();
            String product_info = reviewVO.getProduct_info().getProduct_info();
            String product_img = reviewVO.getProduct_img().getProduct_img();
            
            
            String query = "insert into review(review_id, content, product_id, user_id) values (?, ?, ?, ?)";
            System.out.println("prepareStatement: " + query);
            pstmt = con.prepareStatement(query);
            pstmt.setString(1, review_id);
            pstmt.setString(2, content);
            pstmt.setString(3, product_id);
			pstmt.setString(4, userName);
			pstmt.setString(5, product_name);
			pstmt.setString(6, likes);
			pstmt.setString(7, veiw_count);
			pstmt.setString(8, product_info);
			pstmt.setString(9, product_img);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		}

		public void delReview(String review_id) {
		try {
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/portfolio?characterEncoding=UTF-8&amp;serverTimezone=Asia/Seoul", "root", "root");

		String query = "delete from review where review_id=?";
		System.out.println("prepareStatement: " + query);
		pstmt = con.prepareStatement(query);
		pstmt.setString(1, review_id);
		pstmt.executeUpdate();
		pstmt.close();
	} catch (Exception e) {
		e.printStackTrace();
	}
		}
}