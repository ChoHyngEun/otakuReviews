package com.portfolio.review.model;




import java.sql.Date;

import com.portfolio.product.model.ProductVO;
import com.portfolio.registration.model.User;

public class ReviewVO {

	
	private String review_id;
	private String content;
	private ProductVO product_id;
	private User userName;
	private Date reviewdate;
	private ProductVO product_name;
	private ProductVO product_info;
	private String likes;
	private String view_count;
	private ProductVO product_img;
	
	
	
	public String getReview_id() {
		return review_id;
	}
	public void setReview_id(String review_id) {
		this.review_id = review_id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public ProductVO getProduct_id() {
		return product_id;
	}
	public void setProduct_id(ProductVO product_id) {
		this.product_id = product_id;
	}
	public User getUserName() {
		return userName;
	}
	public void setUserName(User userName) {
		this.userName = userName;
	}
	public Date getReviewdate() {
		return reviewdate;
	}
	public void setReviewdate(Date reviewdate) {
		this.reviewdate = reviewdate;
	}
	public ProductVO getProduct_name() {
		return product_name;
	}
	public void setProduct_name(ProductVO product_name) {
		this.product_name = product_name;
	}
	public ProductVO getProduct_info() {
		return product_info;
	}
	public void setProduct_info(ProductVO product_info) {
		this.product_info = product_info;
	}
	public String getLikes() {
		return likes;
	}
	public void setLikes(String likes) {
		this.likes = likes;
	}
	public String getView_count() {
		return view_count;
	}
	public void setView_count(String view_count) {
		this.view_count = view_count;
	}
	public ProductVO getProduct_img() {
		return product_img;
	}
	public void setProduct_img(ProductVO product_img) {
		this.product_img = product_img;
	}
	
	
	
}
	
